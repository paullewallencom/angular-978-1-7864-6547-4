// describe('',function(){
// 	var scope = {};
// 	beforeEach(function(){
// 		module('comments');
// 		inject(function($controller){
// 			$controller('CommentController',{$scope:scope});
// 		});
// 	});

// 	it('',function(){
// 		expect(scope.comments).toBeDefined();
// 	});
// });