angular.module('product')
		.service('productService',[function productService(){
			this.getProduct = function(){};
		}]);