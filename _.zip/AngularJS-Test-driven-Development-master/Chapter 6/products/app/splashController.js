angular.module('product')
		.controller('SplashController',['$scope',function($scope){
		}]);