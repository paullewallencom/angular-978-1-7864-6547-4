## $5 Tech Unlocked 2021!
[Buy and download this product for only $5 on PacktPub.com](https://www.packtpub.com/)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# AngularJS-Test-driven-Development

This is the code repository for [AngularJS Test-driven Development](https://www.packtpub.com/web-development/angularjs-test-driven-development?utm_source=github&utm_medium=repository&utm_campaign=9781784398835), published by Packt. It contains all the supporting project files necessary to work through the book from start to finish.

All of the code is organized into folders.

## Related AngularJS books

* [AngularJS Web Application Development Cookbook](https://www.packtpub.com/web-development/angularjs-web-application-development-cookbook?utm_source=github&utm_medium=repository&utm_campaign=9781783283354)
* [Learning AngularJS Testing-Video](https://www.packtpub.com/web-development/learning-angularjs-testing-video?utm_source=github&utm_medium=repository&utm_campaign=9781782174899)
* [Learning AngularJS for .NET Developers](https://www.packtpub.com/web-development/learning-angularjs-net-developers?utm_source=github&utm_medium=repository&utm_campaign=9781783986606)
