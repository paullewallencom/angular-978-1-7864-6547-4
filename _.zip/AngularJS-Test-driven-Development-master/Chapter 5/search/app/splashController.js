angular.module('search')
		.controller('SplashController',['$scope',function($scope){
		}]);