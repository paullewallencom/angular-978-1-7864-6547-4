var complex = {
	logic : function(){
		//Some Complex Logic
	}
}

var callIt = function(numberOfTimes){
	for(var i = 0;i < numberOfTimes; i++){
		complex.logic(i);
	}
}
